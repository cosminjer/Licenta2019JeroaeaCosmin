﻿using Business.Header;
using Business.Menu;
using Business.Playlist;
using Business.ResultsPage;
using Business.Trending;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using PageObjects;
using PageObjects.Utils;
using System;
using System.Collections.Generic;
using System.IO;

namespace AutomationTestingFII2019
{
    [TestClass]
    public class YTTests
    {
        private HeaderBL header { get; set; }
        private ResultsPageBL results { get; set; }
        private MenuBL menu { get; set; }
        private TrendingBL trending { get; set; }
        private PlaylistBL playlist { get; set; }
        public TestContext TestContext { get; set; }

        [TestInitialize]
        public void Setup()
        {
            Driver.StartBrowser(BrowserType.Chrome);

            header = new HeaderBL();
            results = new ResultsPageBL();
            menu = new MenuBL();
            trending = new TrendingBL();
            playlist = new PlaylistBL();
        }       

        [TestMethod]
        public void ItShouldSearchForVideoAndPlayIt()
        {
            header.SearchSong("staying alive")
                  .Validate()
                  .CheckVideoTitle(0, "Bee Gees - Stayin' Alive (1977)");

            results.OpenVideo(1);
        }

        [TestMethod]
        public void ItShouldLogin()
        {
            header.Login()
                  .OpenAccountDetails()
                  .Validate()
                  .CheckSuccessfulLogin();
        }

        [TestMethod]
        public void ItShouldOpenPlaylist()
        {
            header.Login();
            menu.GotoPlaylist(menu.Map.playlistOld)
                .Validate()
                .CheckPlaylistVideoTitleNo(0, "Childish Gambino - Feels Like Summer (Official Music Video)");
        }

        [TestMethod]
        public void ItShouldSearchForVideoAndAddItToNewPlaylist()
        {
            header.Login()
                  .SearchSong("Solomun - Friends")
                  .OpenVideo(1)
                  .AddVideoToNewPlaylist("FiiPlaylist");
            menu.GotoPlaylistAfterVideoIsAdded()
                .Validate()
                .CheckPlaylistVideoTitleNo(0, "Solomun - Friends (Original Mix)");

        }

        [TestMethod]
        public void ItShouldAddTrendingVideosToPlaylist()
        {
            header.Login();
            menu.GotoTrendings().GotoMusicTrendings();

            var preferredArtists = new List<string> { "INNA", "Delia", "Andra" };
            var ArtistsInPlaylist = trending.AddPreferedArtistsToPlaylist(preferredArtists);

            menu.GotoPlaylist(menu.Map.playlistFavourites);
            Assert.AreEqual(true, playlist.Validate().CheckAddedSongsFromTrendings(ArtistsInPlaylist));
        }


        [TestCleanup]
        public void Cleanup()
        {
            try
            {
                if (TestContext.CurrentTestOutcome != UnitTestOutcome.Passed)
                {

                    string timestamp = DateTime.Now.ToString("yyyy-MM-dd-hhmm-ss");
                    Screenshot ss = ((ITakesScreenshot)Driver.Browser).GetScreenshot();

                    string projectPath = AppDomain.CurrentDomain.BaseDirectory;
                    Directory.CreateDirectory(projectPath + "/Screenshots");

                    string screenshot = ss.AsBase64EncodedString;
                    byte[] screenshotAsByteArray = ss.AsByteArray;
                    string fileName = projectPath + "/Screenshots/" + TestContext.TestName + "-" + timestamp + ".png";
                    ss.SaveAsFile(fileName, ScreenshotImageFormat.Png);

                }

            }
            catch (Exception)

            {
                // Ignore errors if unable to close the browser
            }
            Driver.StopBrowser();
        }

    }
}
