﻿using Business.ResultsPage;
using PageObjects.Base;
using PageObjects.Header;
using static PageObjects.Utils.Framework;
namespace Business.Header
{
    public class HeaderBL : BasePage<HeaderElementMap, HeaderValidator>
    {
        public HeaderBL Login()
        {
            ClickElement(Map.btnLogin);
            ClearText(Map.txtEmail);
            EnterText(Map.txtEmail, "licentatestFii@gmail.com");
            ClickElement(Map.btnNextToPassword);
            EnterText(Map.txtPass, "licentatest123");
            Map.btnNextToLogin.Click();
            return new HeaderBL();
        }
        public HeaderBL OpenAccountDetails()
        {
            ClickElement(Map.btnAvatar);
            return new HeaderBL();
        }

        public ResultsPageBL SearchSong(string songName)
        {
            EnterText(Map.SearchBox,songName);
            ClickElement(Map.btnSearch);
            return new ResultsPageBL();
        }
    }
}
