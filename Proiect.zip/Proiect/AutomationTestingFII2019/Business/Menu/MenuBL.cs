﻿using Business.Playlist;
using Business.Trending;
using OpenQA.Selenium;
using PageObjects.Base;
using PageObjects.Menu;
using System.Threading;
using static PageObjects.Utils.Framework;

namespace Business.Menu
{
    public class MenuBL : BasePage<MenuElementMap, MenuValidator>
    {
        public PlaylistBL GotoPlaylist(IWebElement playlist)
        {
            ClickElement(playlist);
            return new PlaylistBL();
        }

        public PlaylistBL GotoPlaylistAfterVideoIsAdded()
        {
            Thread.Sleep(4000);
            ClickElement(Map.btnMenu);
            ClickElement(Map.playlistFii);
            return new PlaylistBL();
        }
        public TrendingBL GotoTrendings()
        {
            Thread.Sleep(4000);
            ClickElement(Map.Trendings);
            return new TrendingBL();
        }
        
    }
}
