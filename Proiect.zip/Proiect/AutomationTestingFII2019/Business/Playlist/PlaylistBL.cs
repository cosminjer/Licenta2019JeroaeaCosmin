﻿using PageObjects.Base;
using PageObjects.Playlist;

namespace Business.Playlist
{
    public class PlaylistBL : BasePage<PlaylistElementMap, PlaylistValidator>
    {

    }
}
