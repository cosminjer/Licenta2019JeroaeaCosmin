﻿using PageObjects;
using PageObjects.Base;
using PageObjects.ResultsPage;
using System.Threading;
using static PageObjects.Utils.Framework;

namespace Business.ResultsPage
{
    public class ResultsPageBL : BasePage<ResultsPageElementMap, ResultsPageValidator>
    {
        public ResultsPageBL OpenVideo(int videoNo)
        {
            Thread.Sleep(4000);
            ClickElement(Map.SongRetrieved[videoNo]);
            Thread.Sleep(5000);
            return new ResultsPageBL();
        }

        public ResultsPageBL AddVideoToNewPlaylist(string playlistName)
        {
            Thread.Sleep(4000);
            ClickElement(Map.BtnCreateNewPlaylist[3]);
            ClickElement(Map.BtnCreateNewPlaylistFromPopUp);
            ClickElement(Map.TxtNewPlaylistName[0]);
            EnterText(Map.TxtNewPlaylistName[0], playlistName);
            ClickElement(Map.BtnCreateTheNamedPlaylist[3]);
            return new ResultsPageBL();
            
        }
        
    }
}
