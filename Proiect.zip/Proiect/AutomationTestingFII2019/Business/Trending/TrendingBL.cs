﻿using PageObjects.Base;
using PageObjects.Trending;
using System.Collections.Generic;
using static PageObjects.Utils.Framework;

namespace Business.Trending
{
    public class TrendingBL : BasePage<TrendingElementMap, TrendingValidator>
    {
        public TrendingBL GotoMusicTrendings()
        {
            ClickElement(Map.MusicTrendings);
            return new TrendingBL();
        }

        public List<string> AddPreferedArtistsToPlaylist(List<string> preferedArtists)
        {
            List<string> addedArtists = new List<string>();
            int index = 0;
            foreach (var title in Map.VideoTitle)
            {

                foreach (string artist in preferedArtists)
                {
                    if (title.Text.Contains(artist))
                    {
                        Map.BtnOptionsButton[index].Click();
                        ClickElement(Map.BtnSaveToPlaylist);
                        if (Map.favplaylistChecked.GetAttribute("class") != "checked  style-scope paper-checkbox")
                        {
                            ClickElement(Map.PlaylistFavourites);
                        }

                        ClickElement(Map.BtnClosePlaylistPopup);
                        addedArtists.Add(title.Text);
                    }
                }
                index += 1;
            }
            return addedArtists;
        }

    }
}
