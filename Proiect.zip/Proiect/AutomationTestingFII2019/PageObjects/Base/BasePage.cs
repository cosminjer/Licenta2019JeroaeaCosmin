﻿using PageObjects.Utils;
using System;

namespace PageObjects.Base
{
    public class BasePage<TM> where TM : BasePageElementMap, new()
    {
        private static BasePage<TM> _instance;

        public BasePage()
        {
        }

        public static BasePage<TM> Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new BasePage<TM>();
                }

                return _instance;
            }
        }

        public TM Map
        {
            get
            {
                return new TM();
            }
        }
        
    }

    public class BasePage<TM, TV> : BasePage<TM>
        where TM : BasePageElementMap, new()
        where TV : BasePageValidator<TM>, new()
    {

        public BasePage()
        {

        }

        public TV Validate()
        {            
            return new TV();
        }
    }
}
