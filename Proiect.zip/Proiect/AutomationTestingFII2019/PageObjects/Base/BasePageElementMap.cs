﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;

namespace PageObjects.Base
{
    public class BasePageElementMap
    {
        protected static IWebDriver Browser;
        protected WebDriverWait BrowserWait;
        
        public BasePageElementMap()
        {
            Browser = Driver.Browser;
        }
    }
}