﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using PageObjects.Utils;
using System;
using System.IO;

namespace PageObjects
{
    public class Driver
    {
        private static IWebDriver _browser;

        public static IWebDriver Browser
        {
            get
            {
                if (_browser == null)
                {
                    throw new NullReferenceException(
                        "The WebDriver browser instance was not initialized. You should first call the method Start.");
                }

                return _browser;
            }
            private set { _browser = value; }
        }


        public static void StartBrowser(BrowserType browserType)
        {
            switch (browserType)
            {
                case BrowserType.Chrome:
                    ChromeOptions options = new ChromeOptions();
                    options.AddArgument("--incognito");
                    options.PageLoadStrategy = PageLoadStrategy.None;

                    Browser = Framework.webDriver = new ChromeDriver(options);
                    Browser.Manage().Window.Maximize();

                    break;
                case BrowserType.InternetExplorer:
                    Browser = new InternetExplorerDriver();
                    Browser.Manage().Window.Maximize();
                    break;
                case BrowserType.Firefox:
                    break;
                default:
                    Browser = new ChromeDriver();
                    Browser.Manage().Window.Maximize();
                    break;
            }
            Browser.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            Browser.Navigate().GoToUrl("https://www.youtube.com/");     
        }

        public static void StopBrowser()
        {          
            Browser.Close();
            Browser.Quit();
            Browser.Dispose();
            Browser = null;
        }
    }
}
