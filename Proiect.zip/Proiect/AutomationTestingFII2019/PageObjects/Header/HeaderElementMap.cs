﻿using OpenQA.Selenium;
using PageObjects.Base;

namespace PageObjects.Header
{
    public class HeaderElementMap : BasePageElementMap
    {
        public IWebElement btnSearch => Browser.FindElement(By.Id("search-icon-legacy"));
        public IWebElement SearchBox => Browser.FindElement(By.CssSelector("[name='search_query']"));
        
        public IWebElement btnLogin => Browser.FindElement(By.CssSelector("[class='style-scope ytd-masthead style-suggestive size-small']"));

        public IWebElement txtEmail => Browser.FindElement(By.Id("identifierId"));
        public IWebElement btnNextToPassword => Browser.FindElement(By.Id("identifierNext"));
        public IWebElement txtPass => Browser.FindElement(By.CssSelector("[name='password']"));
        public IWebElement btnNextToLogin => Browser.FindElement(By.Id("passwordNext"));

        public IWebElement btnAvatar => Browser.FindElement(By.Id("avatar-btn"));
        public IWebElement lblaccountName => Browser.FindElement(By.Id("account-name"));

    }
}
