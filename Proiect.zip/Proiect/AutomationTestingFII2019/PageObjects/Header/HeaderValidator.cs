﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PageObjects.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace PageObjects.Header
{
    public class HeaderValidator: BasePageValidator<HeaderElementMap>
    {
        public void CheckSuccessfulLogin()
        {
            Assert.AreEqual(true, Map.btnAvatar.Displayed);
        }
    }
}
