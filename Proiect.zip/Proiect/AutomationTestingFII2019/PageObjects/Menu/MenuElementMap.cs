﻿using OpenQA.Selenium;
using PageObjects.Base;
using System.Collections.Generic;

namespace PageObjects.Menu
{
    public class MenuElementMap : BasePageElementMap
    {
        public IWebElement btnMenu => Browser.FindElement(By.Id("guide-icon"));
        public IWebElement playlistOld => Browser.FindElement(By.CssSelector("[title='Old']"));
        public IWebElement playlistFii => Browser.FindElement(By.CssSelector("[title='FiiPlaylist']"));
        public IWebElement playlistFavourites => Browser.FindElement(By.CssSelector("[title='Favourites']"));
        //public IList<IWebElement> PlaylistSongsList => Browser.FindElements(By.CssSelector("[class='style-scope ytd-playlist-video-renderer']"));
        public IWebElement Trendings => Browser.FindElement(By.CssSelector("a[title='Trending']>paper-item"));
    }
}
