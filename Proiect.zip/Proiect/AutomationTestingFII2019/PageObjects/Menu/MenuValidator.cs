﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PageObjects.Base;
using System.Collections.Generic;

namespace PageObjects.Menu
{
    public class MenuValidator : BasePageValidator<MenuElementMap>
    {
        
    }
}
