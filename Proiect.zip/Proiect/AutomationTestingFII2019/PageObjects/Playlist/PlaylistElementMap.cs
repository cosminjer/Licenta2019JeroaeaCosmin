﻿using OpenQA.Selenium;
using PageObjects.Base;
using System.Collections.Generic;

namespace PageObjects.Playlist
{
    public class PlaylistElementMap : BasePageElementMap
    {
        public IList<IWebElement> PlaylistSongsList => Browser.FindElements(By.CssSelector("div>h3>span"));

    }
}
