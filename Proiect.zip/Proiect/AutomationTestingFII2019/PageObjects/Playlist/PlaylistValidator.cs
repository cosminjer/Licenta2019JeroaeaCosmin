﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using PageObjects.Base;
using System.Collections.Generic;

namespace PageObjects.Playlist
{
    public class PlaylistValidator : BasePageValidator<PlaylistElementMap>
    {
        public void CheckPlaylistVideoTitleNo(int videoNumber, string Title)
        {
            Assert.AreEqual(Title, Map.PlaylistSongsList[videoNumber].Text);
        }

        public bool CheckAddedSongsFromTrendings(List<string> addedSongs)
        {
            foreach (IWebElement songsInPlaylist in Map.PlaylistSongsList)
            {
                foreach(string songsAdded in addedSongs)
                {
                    if (songsInPlaylist.GetAttribute("title").Contains(songsAdded))
                    {
                        return true;
                    }
                    return false;
                }
            }
            return true;
        }
    }
}
