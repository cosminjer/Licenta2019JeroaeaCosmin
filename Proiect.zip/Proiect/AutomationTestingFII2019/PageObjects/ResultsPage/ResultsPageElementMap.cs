﻿using OpenQA.Selenium;
using PageObjects.Base;
using System.Collections.Generic;

namespace PageObjects.ResultsPage
{
    public class ResultsPageElementMap : BasePageElementMap
    {
        public IList<IWebElement> SongRetrieved => Browser.FindElements(By.CssSelector("[class='text-wrapper style-scope ytd-video-renderer']"));
        public IList<IWebElement> SongTitle => Browser.FindElements(By.CssSelector("[class='yt-simple-endpoint style-scope ytd-video-renderer']"));
        public IList<IWebElement> BtnAddToPlaylist => Browser.FindElements(By.CssSelector("div[id='top-level-buttons']>ytd-button-renderer"));
        public IList<IWebElement> BtnCreateNewPlaylist => Browser.FindElements(By.CssSelector("div[id='top-level-buttons']>ytd-button-renderer"));
        public IWebElement BtnCreateNewPlaylistFromPopUp => Browser.FindElement(By.CssSelector("a[id='endpoint']>paper-item>div[id='content-icon']"));
        public IList<IWebElement> TxtNewPlaylistName => Browser.FindElements(By.CssSelector("div[id='labelAndInputContainer']>iron-input>input"));
        public IList<IWebElement> BtnCreateTheNamedPlaylist => Browser.FindElements(By.CssSelector("a[class='yt-simple-endpoint style-scope ytd-button-renderer']>paper-button"));
    }
}
