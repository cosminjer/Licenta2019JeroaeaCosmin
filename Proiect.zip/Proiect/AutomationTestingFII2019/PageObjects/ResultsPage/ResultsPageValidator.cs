﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PageObjects.Base;

namespace PageObjects.ResultsPage
{
    public class ResultsPageValidator : BasePageValidator<ResultsPageElementMap>
    {
        public void CheckVideoTitle(int songNumber, string songTitleToBeChecked)
        {
            Assert.AreEqual(songTitleToBeChecked, Map.SongTitle[songNumber].Text);
        }
    }
}
