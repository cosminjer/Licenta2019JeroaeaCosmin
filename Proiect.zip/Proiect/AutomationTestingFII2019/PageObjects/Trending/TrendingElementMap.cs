﻿using OpenQA.Selenium;
using PageObjects.Base;
using System.Collections.Generic;

namespace PageObjects.Trending
{
    public class TrendingElementMap : BasePageElementMap
    {
        public IWebElement MusicTrendings => Browser.FindElement(By.CssSelector("div[id='contents']>ytd-channel-list-sub-menu-avatar-renderer:nth-child(1)"));
        public IWebElement MoviesTrendings => Browser.FindElement(By.CssSelector("div[id='contents']>ytd-channel-list-sub-menu-avatar-renderer:nth-child(1)"));
        public IWebElement GamesTrendings => Browser.FindElement(By.CssSelector("div[id='contents']>ytd-channel-list-sub-menu-avatar-renderer:nth-child(1)"));
        public IList<IWebElement> VideoTitle => Browser.FindElements(By.CssSelector("div[id='meta']>div>h3>a"));
        public IList<IWebElement> BtnOptionsButton => Browser.FindElements(By.CssSelector("div[id='meta']>div>div>ytd-menu-renderer>yt-icon-button>button"));
        public IWebElement BtnSaveToPlaylist => Browser.FindElement(By.CssSelector("paper-listbox[id='items']>ytd-menu-service-item-renderer:nth-child(2)"));
        public IWebElement PlaylistFavourites => Browser.FindElement(By.CssSelector("div[id='checkboxLabel']>div>div>yt-formatted-string[title='Favourites']"));
        public IWebElement BtnClosePlaylistPopup => Browser.FindElement(By.CssSelector("button[id='button']>yt-icon[icon='close']"));

        public IWebElement favplaylistChecked => Browser.FindElement(By.XPath(@"//yt-formatted-string[@title='Favourites']
                                                                                //parent::div//parent::div//parent::div
                                                                                //parent::div//parent::paper-checkbox
                                                                                //preceding-sibling::div[@id='checkboxContainer']
                                                                                //child::div[1]"));

        public IList<IWebElement> ListForCss => Browser.FindElements(By.CssSelector("paper-checkbox[id='checkbox']>div>div"));
    }
}
