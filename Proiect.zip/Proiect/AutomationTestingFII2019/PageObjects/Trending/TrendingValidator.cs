﻿using PageObjects.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace PageObjects.Trending
{
    public class TrendingValidator: BasePageValidator<TrendingElementMap>
    {

    }
}
