﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PageObjects.Utils
{
    public enum BrowserType
    {
        Chrome,
        Firefox,
        InternetExplorer
    }
}
