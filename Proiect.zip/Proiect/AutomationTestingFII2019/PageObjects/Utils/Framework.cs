﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;

namespace PageObjects.Utils
{
    public static class Framework
    {
        public static IWebDriver webDriver { get; set; }

        public static void ClickElement(IWebElement element)
        {
            WaitForElementVisibility(element);
            IsElementDisplayed(element);
            FluentWait(element);

            Actions actions = new Actions(webDriver);
            actions.MoveToElement(element);
            actions.Build().Perform();

            element.Click();
            Thread.Sleep(2000);
        }

        public static void EnterText(IWebElement element, string input)
        {
            WaitForElementVisibility(element);
            IsElementDisplayed(element);
            FluentWait(element);

            Actions actions = new Actions(webDriver);
            actions.MoveToElement(element);
            actions.Build().Perform();
            element.SendKeys(input);
            Thread.Sleep(2000);
        }

        public static void ClearText(IWebElement element)
        {
            FluentWait(element);
            Actions actions = new Actions(webDriver);
            actions.MoveToElement(element);
            actions.Build().Perform();
            element.Click();

            element.SendKeys(Keys.Control + "a");
            element.SendKeys(Keys.Control + Keys.Backspace);

        }

        public static IList<IWebElement> WaitForElementVisibility(IWebElement element)
        {
            var wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(122));
            wait.PollingInterval = TimeSpan.FromSeconds(5);

            var elements = new List<IWebElement> { element };

            var list = new ReadOnlyCollection<IWebElement>(elements);

            wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(list));
            return list;
        }

        public static IWebElement FluentWait(IWebElement element)
        {
            DefaultWait<IWebDriver> fluentWait = new DefaultWait<IWebDriver>(webDriver);

            fluentWait.Timeout = TimeSpan.FromSeconds(20);

            fluentWait.PollingInterval = TimeSpan.FromSeconds(5);

            fluentWait.IgnoreExceptionTypes(typeof(NoSuchElementException),
                                            typeof(ElementClickInterceptedException),
                                            typeof(ElementNotVisibleException),
                                            typeof(ElementNotSelectableException),
                                            typeof(ElementNotInteractableException));

            IWebElement result = fluentWait.Until(ExpectedConditions.ElementToBeClickable(element));
            return result;
        }
        public static bool IsElementDisplayed(IWebElement element)
        {
            if (element.Text.Length > 0)
            {
                if (element.Displayed)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
    }
}
